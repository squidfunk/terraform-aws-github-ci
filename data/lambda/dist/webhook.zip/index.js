module.exports = function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) {
      return installedModules[moduleId].exports;
    }
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) {
      Object.defineProperty(exports, name, {
        configurable: false,
        enumerable: true,
        get: getter
      });
    }
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function getDefault() {
      return module["default"];
    } : function getModuleExports() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 6);
}([ function(module, exports) {
  module.exports = require("aws-sdk");
}, function(module, exports) {
  module.exports = require("github");
}, , , , , function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  var _slicedToArray = function() {
    function sliceIterator(arr, i) {
      var _arr = [];
      var _n = true;
      var _d = false;
      var _e = undefined;
      try {
        for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
          _arr.push(_s.value);
          if (i && _arr.length === i) break;
        }
      } catch (err) {
        _d = true;
        _e = err;
      } finally {
        try {
          if (!_n && _i["return"]) _i["return"]();
        } finally {
          if (_d) throw _e;
        }
      }
      return _arr;
    }
    return function(arr, i) {
      if (Array.isArray(arr)) {
        return arr;
      } else if (Symbol.iterator in Object(arr)) {
        return sliceIterator(arr, i);
      } else {
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
      }
    };
  }();
  var _awsSdk = __webpack_require__(0);
  var _awsSdk2 = _interopRequireDefault(_awsSdk);
  var _github = __webpack_require__(1);
  var _github2 = _interopRequireDefault(_github);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  var codebuild = new _awsSdk2.default.CodeBuild({
    apiVersion: "2016-10-06"
  });
  var github = new _github2.default();
  if (process.env.GITHUB_OAUTH_TOKEN) github.authenticate({
    type: "oauth",
    token: process.env.GITHUB_OAUTH_TOKEN
  });
  exports.default = function(event, context, cb) {
    event.Records.reduce(function(promise, record) {
      var type = record.Sns.MessageAttributes["X-Github-Event"].Value;
      var message = JSON.parse(record.Sns.Message);
      var _ref = type === "pull_request" ? [ message.pull_request.head.sha, message.pull_request.head.ref ] : [ message.after, message.ref.replace("refs/heads/", "") ], _ref2 = _slicedToArray(_ref, 2), sha = _ref2[0], ref = _ref2[1];
      return promise.then(function() {
        if (type === "pull_request" && message.pull_request.state !== "closed" || type === "push" && ref === "master") {
          return new Promise(function(resolve, reject) {
            codebuild.startBuild({
              projectName: message.repository.name,
              sourceVersion: sha,
              environmentVariablesOverride: [ {
                name: "GIT_BRANCH",
                value: ref
              }, {
                name: "GIT_COMMIT",
                value: sha
              } ]
            }, function(err) {
              return err ? reject(err) : resolve();
            });
          }).then(function() {
            return github.repos.createStatus({
              owner: message.repository.owner.login,
              repo: message.repository.name,
              sha: sha,
              state: "pending",
              context: process.env.GITHUB_REPORTER,
              description: "Waiting for status to be reported"
            });
          });
        }
      });
    }, Promise.resolve()).then(function(data) {
      return cb(null, data);
    }).catch(cb);
  };
} ]);