"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const GitHub = require("github");
const aws_sdk_1 = require("aws-sdk");
const mapping = {
    SUBMITTED: {
        SUCCEEDED: ["pending", "Provisioning"]
    },
    INSTALL: {
        FAILED: ["error", "Provisioning failed"],
        SUCCEEDED: ["pending", "Build running"]
    },
    BUILD: {
        FAILED: ["failure", "Build failed"],
        FAULT: ["error", "Build errored"],
        STOPPED: ["error", "Build stopped"],
        TIMED_OUT: ["error", "Build timed out"]
    }
};
const badges = {
    success: "./badges/passing.svg",
    failure: "./badges/failing.svg",
    error: "./badges/errored.svg"
};
const s3 = new aws_sdk_1.S3({ apiVersion: "2006-03-01" });
const github = new GitHub();
if (process.env.GITHUB_OAUTH_TOKEN)
    github.authenticate({
        type: "oauth",
        token: process.env.GITHUB_OAUTH_TOKEN
    });
exports.default = (event, _, cb) => {
    const info = event.detail["additional-information"];
    const sha = info["source-version"];
    const [, owner, repo] = /github.com\/([^/]+)\/([^/.]+)/
        .exec(info.source.location) || [];
    const phase = mapping[event.detail["completed-phase"]] || {};
    let [state, description] = phase[event.detail["completed-phase-status"]] || [undefined, undefined];
    if (event.detail["completed-phase"] === "FINALIZING")
        if (!info.phases.find(prev => {
            return prev["phase-type"] !== "COMPLETED" &&
                prev["phase-status"] !== "SUCCEEDED";
        }))
            [state, description] = ["success", "Build successful"];
    const ref = info.environment["environment-variables"][0].value;
    const run = event.detail["build-id"].split(":").pop();
    const url = `https://console.aws.amazon.com/codebuild/home?region=${process.env.AWS_REGION}#/builds/${repo}:${run}/view/new`;
    if (state && description) {
        github.repos.createStatus({
            owner, repo, sha, state, description,
            target_url: url,
            context: process.env.GITHUB_REPORTER
        })
            .then(() => {
            return new Promise((resolve, reject) => {
                if (ref === "master" && badges[state]) {
                    s3.putObject({
                        Bucket: process.env.CODEBUILD_BUCKET,
                        Key: `${repo}/status.svg`,
                        Body: fs.readFileSync(badges[state], "utf8"),
                        ACL: "public-read",
                        CacheControl: "no-cache, no-store, must-revalidate",
                        ContentType: "image/svg+xml"
                    }, err => {
                        return err
                            ? reject(err)
                            : resolve();
                    });
                }
                else {
                    resolve();
                }
            });
        })
            .then(data => cb(undefined, data))
            .catch(cb);
    }
};
