"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GitHub = require("github");
const aws_sdk_1 = require("aws-sdk");
const codebuild = new aws_sdk_1.CodeBuild({ apiVersion: "2016-10-06" });
const github = new GitHub();
if (process.env.GITHUB_OAUTH_TOKEN)
    github.authenticate({
        type: "oauth",
        token: process.env.GITHUB_OAUTH_TOKEN
    });
exports.default = (event, _, cb) => {
    event.Records.reduce((promise, record) => {
        const type = record.Sns.MessageAttributes["X-Github-Event"].Value;
        const message = JSON.parse(record.Sns.Message);
        const [sha, ref] = type === "pull_request"
            ? [message.pull_request.head.sha, message.pull_request.head.ref]
            : [message.after, message.ref.replace("refs/heads/", "")];
        return promise.then(() => {
            if (type === "pull_request" && message.pull_request.state !== "closed" ||
                type === "push" && ref === "master") {
                return new Promise((resolve, reject) => {
                    codebuild.startBuild({
                        projectName: message.repository.name,
                        sourceVersion: sha,
                        environmentVariablesOverride: [
                            {
                                name: "GIT_BRANCH",
                                value: ref
                            },
                            {
                                name: "GIT_COMMIT",
                                value: sha
                            }
                        ]
                    }, err => {
                        return err
                            ? reject(err)
                            : resolve();
                    });
                })
                    .then(() => {
                    return github.repos.createStatus({
                        owner: message.repository.owner.login,
                        repo: message.repository.name,
                        sha,
                        state: "pending",
                        context: process.env.GITHUB_REPORTER,
                        description: "Waiting for status to be reported"
                    });
                });
            }
            else {
                return Promise.resolve();
            }
        });
    }, Promise.resolve())
        .then(data => cb(undefined, data))
        .catch(cb);
};
