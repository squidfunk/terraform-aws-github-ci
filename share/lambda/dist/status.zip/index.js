module.exports = function(t) {
    function e(n) {
        if (i[n]) return i[n].exports;
        var r = i[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(r.exports, r, r.exports, e), r.l = !0, r.exports;
    }
    var i = {};
    return e.m = t, e.c = i, e.d = function(t, i, n) {
        e.o(t, i) || Object.defineProperty(t, i, {
            configurable: !1,
            enumerable: !0,
            get: n
        });
    }, e.n = function(t) {
        var i = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return e.d(i, "a", i), i;
    }, e.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, e.p = "", e(e.s = 2);
}([ function(t, e) {
    t.exports = require("github");
}, function(t, e) {
    t.exports = require("aws-sdk");
}, function(t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = i(0), r = i(1), o = i(3), l = i(4), a = i(5), s = {
        SUBMITTED: {
            SUCCEEDED: [ "pending", "Provisioning" ]
        },
        INSTALL: {
            FAILED: [ "error", "Provisioning failed" ],
            SUCCEEDED: [ "pending", "Build running" ]
        },
        BUILD: {
            FAILED: [ "failure", "Build failed" ],
            FAULT: [ "error", "Build errored" ],
            STOPPED: [ "error", "Build stopped" ],
            TIMED_OUT: [ "error", "Build timed out" ]
        }
    }, f = {
        success: a,
        failure: l,
        error: o
    }, c = new r.S3({
        apiVersion: "2006-03-01"
    }), p = new n();
    process.env.GITHUB_OAUTH_TOKEN && p.authenticate({
        type: "oauth",
        token: process.env.GITHUB_OAUTH_TOKEN
    }), e.default = function(t, e, i) {
        var n = t.detail["additional-information"], r = n["source-version"], o = /github.com\/([^\/]+)\/([^\/.]+)/.exec(n.source.location) || [], l = o[1], a = o[2], d = s[t.detail["completed-phase"]] || {}, u = d[t.detail["completed-phase-status"]] || [ void 0, void 0 ], h = u[0], x = u[1];
        "FINALIZING" === t.detail["completed-phase"] && (n.phases.find(function(t) {
            return "COMPLETED" !== t["phase-type"] && "SUCCEEDED" !== t["phase-status"];
        }) || (w = [ "success", "Build successful" ], h = w[0], x = w[1]));
        var g = n.environment["environment-variables"][0].value, v = t.detail["build-id"].split(":").pop(), m = "https://console.aws.amazon.com/codebuild/home?region=" + process.env.AWS_REGION + "#/builds/" + a + ":" + v + "/view/new";
        h && x && p.repos.createStatus({
            owner: l,
            repo: a,
            sha: r,
            state: h,
            description: x,
            target_url: m,
            context: process.env.GITHUB_REPORTER
        }).then(function() {
            return new Promise(function(t, e) {
                "master" === g && f[h] ? c.putObject({
                    Bucket: process.env.CODEBUILD_BUCKET,
                    Key: a + "/status.svg",
                    Body: f[h],
                    ACL: "public-read",
                    CacheControl: "no-cache, no-store, must-revalidate",
                    ContentType: "image/svg+xml"
                }, function(i) {
                    return i ? e(i) : t();
                }) : t();
            });
        }).then(function(t) {
            return i(void 0, t);
        }).catch(i);
        var w;
    };
}, function(t, e) {
    t.exports = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="88" height="20"><linearGradient id="b" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient><clipPath id="a"><rect width="88" height="20" rx="3" fill="#fff"/></clipPath><g clip-path="url(#a)"><path fill="#555" d="M0 0h37v20H0z"/><path fill="#e05d44" d="M37 0h51v20H37z"/><path fill="url(#b)" d="M0 0h88v20H0z"/></g><g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="110"><text x="195" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="270">build</text><text x="195" y="140" transform="scale(.1)" textLength="270">build</text><text x="615" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="410">errored</text><text x="615" y="140" transform="scale(.1)" textLength="410">errored</text></g> </svg>';
}, function(t, e) {
    t.exports = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="20"><linearGradient id="b" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient><clipPath id="a"><rect width="80" height="20" rx="3" fill="#fff"/></clipPath><g clip-path="url(#a)"><path fill="#555" d="M0 0h37v20H0z"/><path fill="#e05d44" d="M37 0h43v20H37z"/><path fill="url(#b)" d="M0 0h80v20H0z"/></g><g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="110"><text x="195" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="270">build</text><text x="195" y="140" transform="scale(.1)" textLength="270">build</text><text x="575" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="330">failing</text><text x="575" y="140" transform="scale(.1)" textLength="330">failing</text></g> </svg>';
}, function(t, e) {
    t.exports = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="88" height="20"><linearGradient id="b" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient><clipPath id="a"><rect width="88" height="20" rx="3" fill="#fff"/></clipPath><g clip-path="url(#a)"><path fill="#555" d="M0 0h37v20H0z"/><path fill="#4c1" d="M37 0h51v20H37z"/><path fill="url(#b)" d="M0 0h88v20H0z"/></g><g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="110"><text x="195" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="270">build</text><text x="195" y="140" transform="scale(.1)" textLength="270">build</text><text x="615" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="410">passing</text><text x="615" y="140" transform="scale(.1)" textLength="410">passing</text></g> </svg>';
} ]);