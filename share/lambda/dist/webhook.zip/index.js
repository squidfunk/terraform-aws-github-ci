module.exports = function(e) {
    function r(n) {
        if (t[n]) return t[n].exports;
        var o = t[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports;
    }
    var t = {};
    return r.m = e, r.c = t, r.d = function(e, t, n) {
        r.o(e, t) || Object.defineProperty(e, t, {
            configurable: !1,
            enumerable: !0,
            get: n
        });
    }, r.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return r.d(t, "a", t), t;
    }, r.o = function(e, r) {
        return Object.prototype.hasOwnProperty.call(e, r);
    }, r.p = "", r(r.s = 6);
}([ function(e, r) {
    e.exports = require("github");
}, function(e, r) {
    e.exports = require("aws-sdk");
}, , , , , function(e, r, t) {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = t(1), o = t(0), u = new n.CodeBuild({
        apiVersion: "2016-10-06"
    }), s = new o();
    process.env.GITHUB_OAUTH_TOKEN && s.authenticate({
        type: "oauth",
        token: process.env.GITHUB_OAUTH_TOKEN
    }), r.default = function(e, r, t) {
        e.Records.reduce(function(e, r) {
            var t = r.Sns.MessageAttributes["X-Github-Event"].StringValue, n = JSON.parse(r.Sns.Message), o = "pull_request" === t ? [ n.pull_request.head.sha, n.pull_request.head.ref ] : [ n.after, n.ref.replace("refs/heads/", "") ], i = o[0], a = o[1];
            return e.then(function() {
                return "pull_request" === t && "closed" !== n.pull_request.state || "push" === t && "master" === a ? new Promise(function(e, r) {
                    u.startBuild({
                        projectName: n.repository.name,
                        sourceVersion: i,
                        environmentVariablesOverride: [ {
                            name: "GIT_BRANCH",
                            value: a
                        }, {
                            name: "GIT_COMMIT",
                            value: i
                        } ]
                    }, function(t) {
                        return t ? r(t) : e();
                    });
                }).then(function() {
                    return s.repos.createStatus({
                        owner: n.repository.owner.login,
                        repo: n.repository.name,
                        sha: i,
                        state: "pending",
                        context: process.env.GITHUB_REPORTER,
                        description: "Waiting for status to be reported"
                    });
                }) : Promise.resolve();
            });
        }, Promise.resolve()).then(function(e) {
            return t(void 0, e);
        }).catch(t);
    };
} ]);