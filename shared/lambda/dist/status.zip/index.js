module.exports = function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) {
      return installedModules[moduleId].exports;
    }
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) {
      Object.defineProperty(exports, name, {
        configurable: false,
        enumerable: true,
        get: getter
      });
    }
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function getDefault() {
      return module["default"];
    } : function getModuleExports() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 2);
}([ function(module, exports) {
  module.exports = require("aws-sdk");
}, function(module, exports) {
  module.exports = require("github");
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  var _slicedToArray = function() {
    function sliceIterator(arr, i) {
      var _arr = [];
      var _n = true;
      var _d = false;
      var _e = undefined;
      try {
        for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
          _arr.push(_s.value);
          if (i && _arr.length === i) break;
        }
      } catch (err) {
        _d = true;
        _e = err;
      } finally {
        try {
          if (!_n && _i["return"]) _i["return"]();
        } finally {
          if (_d) throw _e;
        }
      }
      return _arr;
    }
    return function(arr, i) {
      if (Array.isArray(arr)) {
        return arr;
      } else if (Symbol.iterator in Object(arr)) {
        return sliceIterator(arr, i);
      } else {
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
      }
    };
  }();
  var _awsSdk = __webpack_require__(0);
  var _awsSdk2 = _interopRequireDefault(_awsSdk);
  var _github = __webpack_require__(1);
  var _github2 = _interopRequireDefault(_github);
  var _errored = __webpack_require__(3);
  var _errored2 = _interopRequireDefault(_errored);
  var _failing = __webpack_require__(4);
  var _failing2 = _interopRequireDefault(_failing);
  var _passing = __webpack_require__(5);
  var _passing2 = _interopRequireDefault(_passing);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  var PHASES = {
    SUBMITTED: {
      SUCCEEDED: [ "pending", "Provisioning" ]
    },
    INSTALL: {
      FAILED: [ "error", "Provisioning failed" ],
      SUCCEEDED: [ "pending", "Build running" ]
    },
    BUILD: {
      FAILED: [ "failure", "Build failed" ],
      FAULT: [ "error", "Build errored" ],
      STOPPED: [ "error", "Build stopped" ],
      TIMED_OUT: [ "error", "Build timed out" ]
    }
  };
  var BADGES = {
    success: _passing2.default,
    failure: _failing2.default,
    error: _errored2.default
  };
  var s3 = new _awsSdk2.default.S3({
    apiVersion: "2006-03-01"
  });
  var github = new _github2.default();
  if (process.env.GITHUB_OAUTH_TOKEN) github.authenticate({
    type: "oauth",
    token: process.env.GITHUB_OAUTH_TOKEN
  });
  exports.default = function(event, context, cb) {
    var info = event.detail["additional-information"];
    var sha = info["source-version"];
    var _ref = /github.com\/([^\/]+)\/([^\/.]+)/.exec(info.source.location) || [], _ref2 = _slicedToArray(_ref, 3), owner = _ref2[1], repo = _ref2[2];
    var phase = PHASES[event.detail["completed-phase"]] || {};
    var _ref3 = phase[event.detail["completed-phase-status"]] || [], _ref4 = _slicedToArray(_ref3, 2), state = _ref4[0], description = _ref4[1];
    if (event.detail["completed-phase"] === "FINALIZING") if (!info.phases.find(function(prev) {
      return prev["phase-type"] !== "COMPLETED" && prev["phase-status"] !== "SUCCEEDED";
    })) {
      state = "success";
      description = "Build successful";
    }
    var ref = info.environment["environment-variables"][0].value;
    var run = event.detail["build-id"].split(":").pop();
    var url = "https://console.aws.amazon.com/codebuild/home?region=" + process.env.AWS_REGION + "#/builds/" + repo + ":" + run + "/view/new";
    if (state && description) {
      github.repos.createStatus({
        owner: owner,
        repo: repo,
        sha: sha,
        state: state,
        description: description,
        target_url: url,
        context: process.env.GITHUB_REPORTER
      }).then(function() {
        return new Promise(function(resolve, reject) {
          if (ref === "master" && BADGES[state]) {
            s3.putObject({
              Bucket: process.env.CODEBUILD_BUCKET,
              Key: repo + "/status.svg",
              Body: BADGES[state],
              ACL: "public-read",
              CacheControl: "no-cache, no-store, must-revalidate",
              ContentType: "image/svg+xml"
            }, function(err) {
              return err ? reject(err) : resolve();
            });
          } else {
            resolve();
          }
        });
      }).then(function(data) {
        return cb(null, data);
      }).catch(cb);
    }
  };
}, function(module, exports) {
  module.exports = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="88" height="20"><linearGradient id="b" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient><clipPath id="a"><rect width="88" height="20" rx="3" fill="#fff"/></clipPath><g clip-path="url(#a)"><path fill="#555" d="M0 0h37v20H0z"/><path fill="#e05d44" d="M37 0h51v20H37z"/><path fill="url(#b)" d="M0 0h88v20H0z"/></g><g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="110"><text x="195" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="270">build</text><text x="195" y="140" transform="scale(.1)" textLength="270">build</text><text x="615" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="410">errored</text><text x="615" y="140" transform="scale(.1)" textLength="410">errored</text></g> </svg>';
}, function(module, exports) {
  module.exports = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="20"><linearGradient id="b" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient><clipPath id="a"><rect width="80" height="20" rx="3" fill="#fff"/></clipPath><g clip-path="url(#a)"><path fill="#555" d="M0 0h37v20H0z"/><path fill="#e05d44" d="M37 0h43v20H37z"/><path fill="url(#b)" d="M0 0h80v20H0z"/></g><g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="110"><text x="195" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="270">build</text><text x="195" y="140" transform="scale(.1)" textLength="270">build</text><text x="575" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="330">failing</text><text x="575" y="140" transform="scale(.1)" textLength="330">failing</text></g> </svg>';
}, function(module, exports) {
  module.exports = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="88" height="20"><linearGradient id="b" x2="0" y2="100%"><stop offset="0" stop-color="#bbb" stop-opacity=".1"/><stop offset="1" stop-opacity=".1"/></linearGradient><clipPath id="a"><rect width="88" height="20" rx="3" fill="#fff"/></clipPath><g clip-path="url(#a)"><path fill="#555" d="M0 0h37v20H0z"/><path fill="#4c1" d="M37 0h51v20H37z"/><path fill="url(#b)" d="M0 0h88v20H0z"/></g><g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="110"><text x="195" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="270">build</text><text x="195" y="140" transform="scale(.1)" textLength="270">build</text><text x="615" y="150" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="410">passing</text><text x="615" y="140" transform="scale(.1)" textLength="410">passing</text></g> </svg>';
} ]);